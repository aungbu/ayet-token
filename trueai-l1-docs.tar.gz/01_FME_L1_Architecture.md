# 01 — FME Layer 1 Architecture

*Reference for TrueAI and the FME team. Describes the FME production Layer 1 so TrueAI can
explain it to customers and support engineers. TrueAI never modifies production; this is
knowledge only. Items marked [FME to complete] need the FME team's specific input.*

## What the FME L1 is
FME, Inc. operates a private, permissioned, Ethereum-compatible Layer 1 blockchain built on
Hyperledger Besu with QBFT (proof-of-authority) consensus. It hosts the FME native token and
several application tokens.

## Core chain parameters
- Client: Hyperledger Besu v25.1.0 (Java 21, Ubuntu 24.04 base image)
- Consensus: QBFT (IBFT 2.0 family, proof-of-authority)
- Network ID: 77777 (private chain)
- Sync mode: FULL
- Gas: min-gas-price = 0 (free gas, typical for a private enterprise chain)
- Block producer: validator node with mining enabled
- Runtime: Docker container `fme-core` (image tag fme/layer1-engine:1.0 = stock Besu 25.1.0)

## Node launch configuration (fme-core)
- --data-path=/data (host: /opt/FME/core/state) — chain state
- --genesis-file=/config/genesis.json (host: /opt/FME/core/node1) — genesis
- --node-private-key-file=/config/key — the validator key (host: /opt/FME/core/node1/key)
- --network-id=77777
- --rpc-http-enabled, --rpc-http-host=0.0.0.0, --rpc-http-port=8545
- --rpc-http-api=ETH,NET,WEB3,QBFT,ADMIN,TXPOOL
- --min-gas-price=0, --miner-enabled=true, --miner-coinbase=<validator address>
- --p2p-enabled=true, --p2p-port=30303
Note: RPC binds to 0.0.0.0 inside the container but is protected by the host firewall
(ufw) — it is NOT publicly exposed. ADMIN methods must never be reachable from the internet.

## Host configuration layout
- /opt/FME/core/node1/ — genesis.json + validator key (the config mount)
- /opt/FME/core/state/ — chain data (the data mount)
- /opt/FME/qbft/ — QBFT config (qbftConfigFile.json, networkFiles/)
- /opt/FME/validator1/ — validator genesis material

## Tokens on the FME L1 (sources under /opt/FME/contracts/)
UUPS-upgradeable ERC-20 contracts built on OpenZeppelin upgradeable libraries:
- MaruhanToken (MARU)
- MMKStablecoin (MMK)
- JPYCStablecoin (JPYC)
- NihonChokuhanToken (NCK)
- AYET (Akimoto Yasushi Entertainment Token; ERC20Votes + Permit)
- TrueLayer1DPP + LogisticsRegistry (supply-chain / DPP contracts)
[FME to complete: the FME native token contract details and any tokens not listed above.]

## Known design characteristic (security-relevant)
The current tokens grant all privileged roles (admin, minter, pauser, freezer, upgrader) to a
single treasury/owner address at initialization, and mint the full supply to one address.
Professional review (CertiK) and FME's own centralization checker both identify this as a
CENTRALIZATION risk: one key compromise could mint unlimited supply and/or replace a contract
via upgrade. New tokens should improve on this — see doc 03 (Validator Governance & Safe
Policy) and doc 06 (Contract Release & Upgrade Workflow).

## Infrastructure
- Server: HP ProLiant DL380 Gen10, NVIDIA Quadro RTX 8000 48GB, Ubuntu 24.04
- AI stack (TrueAI, audit tools) is isolated under /opt/ai-temp and /mnt/ai — separate from
  the L1. The AI never touches the L1's keys, node, or chain data.
- Public endpoints: l1.aucfans.com / ai.truel1.com / truel1.com
[FME to complete: any additional infrastructure, backup targets, and network topology.]

## Related documents
- 02 Besu/QBFT Operations Runbook — day-to-day operations
- 03 Validator Governance & Safe Policy — keys, validators, multisig
- 04 Rollback & Disaster Recovery
- 05 RPC/P2P & Network Security
- 06 Contract Release & Upgrade Workflow
- 07 Incident Library & Resolved Issues
- 08 Engineer Do-Not-Do List (authoritative safety rules)
